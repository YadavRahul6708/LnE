import 'package:flutter/material.dart';

const kTextStyleAppBarText=TextStyle( fontSize:24,fontWeight:FontWeight.w400,color:Color(0xFF6A7541));
const kTextStyleContinue=TextStyle( fontSize:16,fontWeight:FontWeight.w400,color:Colors.black);
const kTextStyleSixDigitText=TextStyle( fontSize:16,fontWeight:FontWeight.w400,color:Color(0xFF666666));
const kTextStyleTimer=TextStyle( fontSize:24,fontWeight:FontWeight.w400,color:Colors.black);
const kTextStyleResendTextButton=TextStyle( fontSize:18,fontWeight:FontWeight.w400,color:Color(0xFFFBB03B));
const kTextStyleRegularOrSalePrice=TextStyle( fontSize:16,fontWeight:FontWeight.w400,color:Color(0xFF999999));

