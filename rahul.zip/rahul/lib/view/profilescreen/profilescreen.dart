import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:rahul/constants/textstyleconstants.dart';
import 'package:rahul/view/cartscreen/cartscreen.dart';
import 'package:rahul/view/profilescreen/controllerprofile.dart';
import 'package:rahul/widgets/buttons.dart';
import 'package:rahul/widgets/textfield.dart';

class ProfileScreen extends StatefulWidget {
  String number;
  int? id;
  ProfileScreen({required this.number, this.id});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  List<Map<String, dynamic>> _journals = [];
  bool _isloading = true;
  String? destinationPath;
  final _nameTextController = TextEditingController();
  final _emailTextController = TextEditingController();
  late final TextEditingController _mobileNumberController;

  void _refreshJournals() async {
    final data = await ProfileSQLHelper.getItems();
    setState(() {
      _journals = data;
      _isloading = false;
    });
  }

  @override
  void initState() {
    super.initState();
    _showForm(widget.id);
    _refreshJournals();
    _mobileNumberController = TextEditingController(text: widget.number);
  }

  Future<void> _addItem() async {
    print('print$destinationPath');
    print(widget.number);
    await ProfileSQLHelper.createItem(_nameTextController.text,
        _emailTextController.text, widget.number, destinationPath!);
  }

  Future<void> _updateItem(int id) async {
    await ProfileSQLHelper.updateItem(
        id,
        _nameTextController.text,
        _emailTextController.text,
        _mobileNumberController.text,
        destinationPath!);
  }

  void _showForm(int? id) async {
    if (id != null) {
      final existingJournal =
          _journals!.firstWhere((element) => element['id'] == id);
      _nameTextController.text = existingJournal['name'];
      _emailTextController.text = existingJournal['email'];
      _mobileNumberController.text = existingJournal['number'];
      destinationPath = existingJournal['imagepath'];
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFBDEFE6),
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(
            Icons.chevron_left,
            color: Colors.black,
            size: 35,
          ),
          onPressed: () {
            Get.back();
          },
        ),
        title: const Center(
            child: Text(
          'SETUP YOUR PROFILE',
          style: kTextStyleAppBarText,
        )),
        backgroundColor: const Color(0xFFF8CECE),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Center(
              child: Column(
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  GestureDetector(
                    onTap: () async {
                      setState(() {
                        _isloading =
                            true; // Set isLoading to true to display the progress indicator
                      });

                      destinationPath =
                          (await ProfileSQLHelper.getImagePath())!;
                    },
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        CircleAvatar(
                          radius: 100,
                          backgroundColor: Colors.transparent,
                          backgroundImage: destinationPath != null
                              ? FileImage(File(destinationPath!))
                              : null,
                          child: destinationPath == null
                              ? const CircleAvatar(
                                  radius: 100,
                                  backgroundColor: Colors.grey,
                                  child: Icon(
                                    Icons.add_a_photo,
                                    size: 50,
                                    color: Colors.black,
                                  ),
                                )
                              : null,
                        ),
                        // Show progress indicator if isLoading is true and no image is selected
                      ],
                    ),
                  ),
                  const SizedBox(height:10),
                  const Text(
                    'Add Profile Photo/Delete',
                    style: kTextStyleRegularOrSalePrice,
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  textFieldForm('Full Name', Icons.person, _nameTextController,
                      TextInputType.text, 'Please enter full name'),
                  const SizedBox(
                    height: 20,
                  ),
                  textFieldForm('Email-ID', Icons.email, _emailTextController,
                      TextInputType.emailAddress, 'Please enter your email'),
                  const SizedBox(
                    height: 20,
                  ),
                  textFieldForm(
                      'Mobile Number',
                      Icons.mobile_screen_share_rounded,
                      _mobileNumberController,
                      TextInputType.number,
                      ''),
                  const SizedBox(
                    height: 20,
                  ),
                  SizedBox(
                    height: 40,
                    width: double.infinity,
                    child: buttonElevated(
                        (widget.id == null) ? 'Save' : 'Update Profile',
                        () async {
                      if (_formKey.currentState!.validate()) {
                        _formKey.currentState!.save();
                        if (widget.id == null) {
                          await _addItem();
                        }
                        if (widget.id != null) {
                          await _updateItem(widget.id!);
                        }
                        Get.to(() => CartScreen(
                              journal: _journals,
                            ));
                        Get.snackbar('Successfully created',
                            'Your profile created succesfully');
                      }
                      ;
                    }, kTextStyleContinue),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
